var searchData=
[
  ['speedtype',['speedType',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8',1,'PerformanceWidget']]]
];
