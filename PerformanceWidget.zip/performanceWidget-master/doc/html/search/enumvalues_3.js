var searchData=
[
  ['slow_5fupdate',['SLOW_UPDATE',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8a0016b694f51765c4b5fabe6385906cc0',1,'PerformanceWidget']]]
];
