var searchData=
[
  ['ramdataquery',['RamDataQuery',['../class_ram_data_query.html#a361bd19a7b4cd0af5f16c92cb0592297',1,'RamDataQuery']]],
  ['resizeevent',['resizeEvent',['../class_performance_widget.html#abe99b5fb0baf5df52d7570cee82b5acb',1,'PerformanceWidget']]]
];
