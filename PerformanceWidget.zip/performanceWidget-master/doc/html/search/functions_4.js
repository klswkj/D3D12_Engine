var searchData=
[
  ['memoryquery',['MemoryQuery',['../class_memory_query.html#a8fba3532346980a847105eae549f190b',1,'MemoryQuery']]]
];
