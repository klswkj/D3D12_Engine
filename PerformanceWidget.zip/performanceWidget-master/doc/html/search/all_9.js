var searchData=
[
  ['setbackgroundcolor',['setBackgroundColor',['../class_performance_painter.html#a075e00c8afea00ee63c3944c4d8e8773',1,'PerformancePainter']]],
  ['setcolor1',['setColor1',['../class_performance_painter.html#aac08ef6ab7f4ee5cb60dabc74022f4bc',1,'PerformancePainter']]],
  ['setcolor2',['setColor2',['../class_performance_painter.html#a7a01701262a890be29e1d9cf22826590',1,'PerformancePainter']]],
  ['setdata',['setData',['../class_performance_painter.html#a5fe6fcaedd954238348a93a5de09d3d9',1,'PerformancePainter']]],
  ['setdisplaymode',['setDisplayMode',['../class_cpu_widget.html#aadb4598dd612abdf99716e739d8c69c6',1,'CpuWidget::setDisplayMode()'],['../class_ram_widget.html#ada2f5f0a96dc7e2ed3e1b90bb9830759',1,'RamWidget::setDisplayMode()']]],
  ['setdrawgrid',['setDrawGrid',['../class_performance_painter.html#a808d08c3322853b8d0ca444b0542261a',1,'PerformancePainter']]],
  ['setgeometry',['setGeometry',['../class_performance_painter.html#a69c38204cb111963f74518a8be8fa8e4',1,'PerformancePainter']]],
  ['setgridcolor',['setGridColor',['../class_performance_painter.html#a1ff6b84cab5f0e645b1def6095a2261d',1,'PerformancePainter']]],
  ['setindex',['setIndex',['../class_data_query.html#abbd51b4dc0e665de8482a011c3552492',1,'DataQuery::setIndex()'],['../class_cpu_widget.html#a10db9b015760035c8bbe111986c5e2a4',1,'CpuWidget::setIndex()']]],
  ['setmulti',['setMulti',['../class_data_query.html#ae98595c4d6e6e743f0a4877a6ba2530b',1,'DataQuery::setMulti()'],['../class_cpu_widget.html#a1b21ac8d190ca822ca7732ae71074a37',1,'CpuWidget::setMulti()']]],
  ['setspeed',['setSpeed',['../class_performance_widget.html#a0e1302ebabca0143514ac04ea76bfc54',1,'PerformanceWidget']]],
  ['slow_5fupdate',['SLOW_UPDATE',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8a0016b694f51765c4b5fabe6385906cc0',1,'PerformanceWidget']]],
  ['speedtype',['speedType',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8',1,'PerformanceWidget']]]
];
