var searchData=
[
  ['drawmode',['drawMode',['../class_cpu_widget.html#a617a6cbf4adba35e287f6eb6bdc4214d',1,'CpuWidget::drawMode()'],['../class_ram_widget.html#aa291cd02989e48be18fda9cd794f3389',1,'RamWidget::drawMode()']]]
];
