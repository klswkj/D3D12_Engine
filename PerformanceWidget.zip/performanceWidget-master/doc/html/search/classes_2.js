var searchData=
[
  ['dataquery',['DataQuery',['../class_data_query.html',1,'']]]
];
