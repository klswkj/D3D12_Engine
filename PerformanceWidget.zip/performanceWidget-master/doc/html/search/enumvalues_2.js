var searchData=
[
  ['medium_5fupdate',['MEDIUM_UPDATE',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8a73d8bf1ee059478bd9960356fc6851c1',1,'PerformanceWidget']]]
];
