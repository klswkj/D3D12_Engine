var searchData=
[
  ['fast_5fupdate',['FAST_UPDATE',['../class_performance_widget.html#af6c7a2bb2271f1a7a8464fdbc53d46f8ac6646e637791662b20587dc5c90403f5',1,'PerformanceWidget']]]
];
