var searchData=
[
  ['draw_5fbars',['DRAW_BARS',['../class_cpu_widget.html#a617a6cbf4adba35e287f6eb6bdc4214da27fcd0ea3ff013ef49d587c224c5449d',1,'CpuWidget::DRAW_BARS()'],['../class_ram_widget.html#aa291cd02989e48be18fda9cd794f3389a86a0571725a78496f7797e1b443751fb',1,'RamWidget::DRAW_BARS()']]],
  ['draw_5fgraph',['DRAW_GRAPH',['../class_cpu_widget.html#a617a6cbf4adba35e287f6eb6bdc4214da5d7081946e61bfae9c70e9acd90cc0ae',1,'CpuWidget::DRAW_GRAPH()'],['../class_ram_widget.html#aa291cd02989e48be18fda9cd794f3389aafc5918c2cc93cb732e93310e91729c4',1,'RamWidget::DRAW_GRAPH()']]],
  ['draw_5fgraph_5fmulti_5fcolor',['DRAW_GRAPH_MULTI_COLOR',['../class_cpu_widget.html#a617a6cbf4adba35e287f6eb6bdc4214da9730ab1d5bd16b640474bccc056710e7',1,'CpuWidget']]]
];
