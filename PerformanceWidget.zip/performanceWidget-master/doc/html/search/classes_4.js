var searchData=
[
  ['memoryquery',['MemoryQuery',['../class_memory_query.html',1,'']]]
];
