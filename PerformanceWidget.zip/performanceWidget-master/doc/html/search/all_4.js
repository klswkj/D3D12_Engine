var searchData=
[
  ['getallinstantcpus',['getAllInstantCPUs',['../class_cpu_query.html#a9cd555267d218d2c9dfe85e2f45b6e45',1,'CpuQuery']]],
  ['getcpucache',['getCpuCache',['../class_cpu_query.html#ad7ee72ad359a87b109ffccd94753aaf3',1,'CpuQuery']]],
  ['getcpus',['getCPUs',['../class_cpu_query.html#a6cf1dd7e287ad76441b4f9c6a804b958',1,'CpuQuery']]],
  ['getdata',['getData',['../class_cpu_data_query.html#a29522b2d943b09ffa43318055aaa012e',1,'CpuDataQuery::getData()'],['../class_data_query.html#a2fd0f2893be0d746a910f22c7cd032ab',1,'DataQuery::getData()'],['../class_ram_data_query.html#a52272d90b61d5082dbfdfbcf0cc1bcb0',1,'RamDataQuery::getData()']]],
  ['getfreememory',['getFreeMemory',['../class_memory_query.html#a824877fce3502caed393e3f334ab5fd0',1,'MemoryQuery']]],
  ['getinstantcpu',['getInstantCPU',['../class_cpu_query.html#a08ef3414af3c1dec0a3bb958c1a999f8',1,'CpuQuery']]],
  ['getmemoryusage',['getMemoryUsage',['../class_memory_query.html#a3e22fc860c696a3a7d079eb51090b25a',1,'MemoryQuery']]],
  ['getnumberofcores',['getNumberOfCores',['../class_cpu_data_query.html#ab103e525176ff8e9f03d24f9e52bfc6c',1,'CpuDataQuery::getNumberOfCores()'],['../class_cpu_query.html#aa3169ca4010c3f21bc2afd2f5a3f01dc',1,'CpuQuery::getNumberOfCores()']]],
  ['getorderedcpucache',['getOrderedCpuCache',['../class_cpu_query.html#a7b81c08948c49038edca5019cb589803',1,'CpuQuery']]],
  ['getorderedcpuscache',['getOrderedCpusCache',['../class_cpu_query.html#a777d4cff0526df61a31ddaa84f0eaafb',1,'CpuQuery']]],
  ['getorderedmemoryusagecache',['getOrderedMemoryUsageCache',['../class_memory_query.html#a7e4ebeaa9708ed983c547a5fdc96bb21',1,'MemoryQuery']]],
  ['gettotalmem',['getTotalMem',['../class_memory_query.html#a423f1ac5faff9b3e307e940571b40aff',1,'MemoryQuery']]],
  ['getusedmem',['getUsedMem',['../class_memory_query.html#a11ffc8d0fb41f94f69cee5492f06bdb4',1,'MemoryQuery']]],
  ['graphmulticolorpainter',['GraphMultiColorPainter',['../class_graph_multi_color_painter.html',1,'GraphMultiColorPainter'],['../class_graph_multi_color_painter.html#a8bb670b58c84c12530136d4eb8f843f5',1,'GraphMultiColorPainter::GraphMultiColorPainter()']]],
  ['graphpainter',['GraphPainter',['../class_graph_painter.html',1,'GraphPainter'],['../class_graph_painter.html#a59a05087130703a28bf55df4b5723a79',1,'GraphPainter::GraphPainter()']]]
];
