# LearningDirectX12
This repository is intended to be used as a code repository for learning DirectX 12. The tutorials can be found on https://www.3dgep.com

This project uses [CMake](https://cmake.org/) (3.10.1 or newer) to generate the project and solution files. 

To use this project, run the [GenerateProjectFiles.bat](GenerateProjectFiles.bat) script and open the generated Visual Studio 2017 solution file in the build_vs2017 folder.